## SDK Documentation
* The subdirectories included below both contain JSDocs hyperlink documentation of the classes, interfaces, and methods.
* Each SDK has separate documentation.
* Open the primary 'index.html' file using a browser.  These files can be read by the browser directly from the disk system, and do not need to be hosted on a web server.
